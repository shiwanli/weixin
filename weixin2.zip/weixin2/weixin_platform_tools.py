# -*- coding=utf8  -*- 

from wechat_sdk import WechatBasic

import tornado.httpserver
import tornado.web
import tornado.httpclient

import weixin_conf
import base64


# wx424c22aba31c84e1
# 60975daad12f56b443ee01e0f8d7db9c 

# s_appid = 'wxf756e2112161596a'
# s_appsecret = '2be39d0a0388e49fc7db4dcfd746f359'



s_appid = 'wxf756e2112161596a'
s_appsecret = '2be39d0a0388e49fc7db4dcfd746f359'
s_token = "pet_pet"


r = None;
def InitPlatform():
    return None

s_access_token = ""
s_access_token_expires_at = 0
# 获取Token
def GetToken(): 
    global s_access_token ,  s_access_token_expires_at 
    try:
        if r != None:
            s_access_token = r.get('access_token')
            s_access_token_expires_at = r.get('access_token_expires_at')

            # print s_access_token
            # print s_access_token_expires_at

    except Exception, e:
        print e
    finally :
        wechat = WechatBasic(token = s_token,appid=s_appid,appsecret=s_appsecret,
        access_token=s_access_token,access_token_expires_at=int(s_access_token_expires_at));
        token = wechat.get_access_token()
        if r != None:
            r.set('access_token',token['access_token'])
            r.set('access_token_expires_at',token['access_token_expires_at'])
            
        return wechat;

def GetAccessToken():
    wechat = GetToken()
    token = wechat.get_access_token()
    return token['access_token'],token['access_token_expires_at']


# 创建菜单
def CreateMenus():
    global s_access_token,s_access_token_expires_at 
    s_access_token,s_access_token_expires_at= GetAccessToken()

    wechat = WechatBasic(appid=s_appid,appsecret=s_appsecret,
        access_token=s_access_token,access_token_expires_at=s_access_token_expires_at);
    token_json = wechat.get_access_token()
    s_access_token = token_json['access_token']
    s_access_token_expires_at = token_json['access_token_expires_at']

    return wechat.create_menu(weixin_conf.menus);

# 删除菜单
def DeleteMenus():
    global s_access_token,s_access_token_expires_at 
    s_access_token,s_access_token_expires_at = GetAccessToken()

    wechat = WechatBasic(appid=s_appid,appsecret=s_appsecret,
        access_token=s_access_token,access_token_expires_at=s_access_token_expires_at);
    token_json = wechat.get_access_token()
    s_access_token = token_json['access_token']
    s_access_token_expires_at = token_json['access_token_expires_at']
    return wechat.delete_menu();

# 申请二维码
def CreateQRcode(device_list):
    global s_access_token,s_access_token_expires_at 
    s_access_token,s_access_token_expires_at = GetAccessToken()
    url = 'https://api.weixin.qq.com/device/create_qrcode?access_token='
    url = url + s_access_token
    body_text = {"device_num":str(len(device_list)),"device_id_list":device_list}
    body_text = tornado.escape.json_encode(body_text);
    http = tornado.httpclient.HTTPClient()
    request = tornado.httpclient.HTTPRequest(url=url,method='POST',body=body_text)
    return http.fetch(request).body

# 申请二维码
def CreateQRcodeWithoutID():    
    global s_access_token,s_access_token_expires_at 
    s_access_token,s_access_token_expires_at = GetAccessToken() 
    url = 'https://api.weixin.qq.com/device/getqrcode?access_token='
    url = url + s_access_token
    http = tornado.httpclient.HTTPClient()
    request = tornado.httpclient.HTTPRequest(url=url,method='GET')
    return http.fetch(request).body

# 绑定设备
def AuthDevices(device_list):
    global s_access_token,s_access_token_expires_at 
    s_access_token,s_access_token_expires_at = GetAccessToken() 
    url = 'https://api.weixin.qq.com/device/authorize_device?access_token='
    url = url + s_access_token
    body_text = {"device_num":str(len(device_list)),"device_list":device_list,"op_type":"1"}
    body_text = tornado.escape.json_encode(body_text);
    http = tornado.httpclient.HTTPClient()
    request = tornado.httpclient.HTTPRequest(url=url,method='POST',body=body_text,
        headers={'Content-Type':'application/json'})
    return http.fetch(request).body

# 查询设备状态
def queryDeviceStat(device_id):
    global s_access_token,s_access_token_expires_at 
    s_access_token,s_access_token_expires_at = GetAccessToken() 
    url = 'https://api.weixin.qq.com/device/get_stat?access_token='
    url = url + s_access_token + "&device_id=" + device_id
    http = tornado.httpclient.HTTPClient()
    request = tornado.httpclient.HTTPRequest(url=url,method='GET')
    return http.fetch(request).body

# 查询设备属性
def queryDeviceAttr(device_qrticket):
    global s_access_token,s_access_token_expires_at 
    s_access_token,s_access_token_expires_at = GetAccessToken() 
    url = 'https://api.weixin.qq.com/device/verify_qrcode?access_token='
    url = url + s_access_token
    body_text = {"ticket":device_qrticket}
    body_text = tornado.escape.json_encode(body_text);
    http = tornado.httpclient.HTTPClient()
    request = tornado.httpclient.HTTPRequest(url=url,method='POST',body=body_text)
    return http.fetch(request).body


# 查询设备属性
def postDeviceText(dev_type,dev_id,userid,message):
    global s_access_token,s_access_token_expires_at 
    s_access_token,s_access_token_expires_at = GetAccessToken() 
    url = 'https://api.weixin.qq.com/device/transmsg?access_token='
    url = url + s_access_token
    message = base64.standard_b64encode(message);
    body_text = {
        "device_type":dev_type,
        "device_id":dev_id,
        "open_id": userid,
        "content": message
    }

    body_text = tornado.escape.json_encode(body_text);
    http = tornado.httpclient.HTTPClient()
    request = tornado.httpclient.HTTPRequest(url=url,method='POST',body=body_text)
    return http.fetch(request).body

def sendTextMessage(userid,message):
    wechat = GetToken()
    wechat.send_text_message(userid,message)


# 查询设备属性
def postCustomerServerText(dev_type,dev_id,userid,message):
    pass



