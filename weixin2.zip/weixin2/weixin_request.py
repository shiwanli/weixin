# -*- coding=utf8  -*- 
import tornado.gen as gen
import tornado.escape

from iwan_request import BaseRequest

class BindRequest(BaseRequest):
    """docstring for NotyfyBindRequest"""
    def __init__(self):
        super(UnBindRequest, self).__init__()
        self.url = "https://api.weixin.qq.com/device/compel_bind?access_token=ACCESS_TOKEN"

    @gen.coroutine
    def request(self,device_id,openid):
        req_data={
            "device_id": device_id, 
            "openid": openid
        }

        body_text = tornado.escape.json_encode(req_data)
        resp = yield self.do_post(self.url,body_text)
        jsonstr = resp.body;
        jsonstr = jsonstr.decode("string_escape")
        jsondata = tornado.escape.json_decode(jsonstr);

        raise gen.Return(jsondata)

class UnBindRequest(BaseRequest):
    """docstring for NotyfyBindRequest"""
    def __init__(self):
        super(UnBindRequest, self).__init__()
        self.url = "https://api.weixin.qq.com/device/compel_unbind?access_token=ACCESS_TOKEN"

    @gen.coroutine
    def request(self,device_id,openid):
        req_data={
            "device_id": device_id, 
            "openid": openid
        }

        body_text = tornado.escape.json_encode(req_data)
        resp = yield self.do_post(self.url,body_text)
        jsonstr = resp.body;
        jsonstr = jsonstr.decode("string_escape")
        jsondata = tornado.escape.json_decode(jsonstr);

        raise gen.Return(jsondata)


if __name__ == '__main__':

    
    pass


