# -*- coding=utf8  -*- 


from wechat_sdk.reply import WechatReply
# from wechat_sdk.messages import WechatMessage


class DeviceTextMessage(WechatReply): 
    """  
    回复设备消息
    """ 
    TEMPLATE = u""" 
    <xml> 
    <ToUserName><![CDATA[{target}]]></ToUserName> 
    <FromUserName><![CDATA[{source}]]></FromUserName> 
    <CreateTime>{time}</CreateTime> 
    <MsgType><![CDATA[device_text]]></MsgType>
    <DeviceType><![CDATA[{deviceType}]]></DeviceType> 
    <DeviceID><![CDATA[{deviceID}]]></DeviceID> 
    <SessionID>{sessionID}</SessionID> 
    <Content><![CDATA[{content}]]></Content>
    </xml>
    """
    def __init__(self, message,deviceType,deviceID,sessionID,content):
        super(DeviceTextMessage, self).__init__(message=message,deviceType=deviceType,
            deviceID=deviceID,sessionID=sessionID,content=content)

    def render(self):    
        return DeviceTextMessage.TEMPLATE.format(**self._args)


class DeviceEventBandMessage(WechatReply): 
    """  
    回复设备消息
    """ 
    TEMPLATE = u""" 
    <xml> 
    <ToUserName><![CDATA[{target}]]></ToUserName> 
    <FromUserName><![CDATA[{source}]]></FromUserName> 
    <CreateTime>{time}</CreateTime> 
    <MsgType><![CDATA[device_event]]></MsgType>
    <Event><![CDATA[{event}]]></Event>
    <DeviceType><![CDATA[{type}]]></DeviceType> 
    <DeviceID><![CDATA[{id}]]></DeviceID> 
    <SessionID>{sessionID}</SessionID> 
    <Content><![CDATA[{content}]]></Content>
    </xml>
    """
    def __init__(self, message,event,deviceType,deviceID,sessionID):
        super(DeviceEventBandMessage, self).__init__(message=message,event=event,type=deviceType,
            id=deviceID,sessionID=sessionID,content="")

    def render(self):    
        return DeviceEventBandMessage.TEMPLATE.format(**self._args)


class DeviceEventSubcribeMessage(WechatReply): 
    """  
    回复图片消息
    """ 
    TEMPLATE = u""" 
    <xml>
    <ToUserName><![CDATA[{target}]]></ToUserName> 
    <FromUserName><![CDATA[{source}]]></FromUserName> 
    <CreateTime>{time}</CreateTime> 
    <MsgType><![CDATA[device_status]]></MsgType> 
    <DeviceType><![CDATA[{type}]]></DeviceType> 
    <DeviceID><![CDATA[{id}]]></DeviceID> 
    <DeviceStatus>{status}</DeviceStatus>
    </xml>
    """
    def __init__(self, message, type,id,status):
        super(DeviceEventSubcribeMessage, self).__init__(message=message,type=type,id=id,status=status)

    def render(self):       
        return DeviceEventSubcribeMessage.TEMPLATE.format(**self._args)


class DeviceRankMessage(WechatReply): 
    """  
    回复图片消息
    """ 
    TEMPLATE = u"""
    <xml>
    <ToUserName><![CDATA[{target}]]></ToUserName> 
    <FromUserName><![CDATA[{source}]]></FromUserName> 
    <CreateTime>{time}</CreateTime> 
    <MsgType><![CDATA[hardware]]></MsgType> 
    <HardWare>
    <MessageView><![CDATA[myrank]]></MessageView>
    <MessageAction><![CDATA[ranklist]]></MessageAction> 
    </HardWare>
    <FuncFlag>0</FuncFlag> 
    </xml>
    """
    def __init__(self, message):
        super(DeviceRankMessage, self).__init__(message=message)

    def render(self):    
        return DeviceRankMessage.TEMPLATE.format(**self._args)

