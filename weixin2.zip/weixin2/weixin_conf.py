# -*- coding=utf8  -*- 

server_ip = "http://116.205.1.54:23654"
server_port = 23654;


menus = {
     "button":[
     {  
          "name":"轨迹",
          "sub_button":[
           {    
               "type":"view",
               "name":"历史轨迹",
               "url":"https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxf756e2112161596a&redirect_uri=http%3a%2f%2fpet.wx.upcoder.net%2ftrack%2fhistory&response_type=code&scope=snsapi_base&state=123#wechat_redirect"
            },
            {
               "type":"view",
               "name":"最后位置",
               "url":"https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxf756e2112161596a&redirect_uri=http%3a%2f%2fpet.wx.upcoder.net%2ftrack%2flatest&response_type=code&scope=snsapi_base&state=123#wechat_redirect"
            }]
      },
      {
           "name":"电子围栏",
           "sub_button":[
           {    
               "type":"view",
               "name":"查看围栏",
               "url":"https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxf756e2112161596a&redirect_uri=http%3a%2f%2fpet.wx.upcoder.net%2fewall%2flist&response_type=code&scope=snsapi_base&state=123#wechat_redirect"
            },
            {
               "type":"view",
               "name":"添加围栏",
               "url":"https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxf756e2112161596a&redirect_uri=http%3a%2f%2fpet.wx.upcoder.net%2fewall%2fnew&response_type=code&scope=snsapi_base&state=123#wechat_redirect"
            }]
       },
       {
           "name":"宠物信息",
           "sub_button":[
            {
               "type":"view",
               "name":"设备绑定",
               "url":"https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxf756e2112161596a&redirect_uri=http%3a%2f%2fpet.wx.upcoder.net%2fpet%2fbind&response_type=code&scope=snsapi_base&state=123#wechat_redirect"
            },
            {    
               "type":"view",
               "name":"宠物资料",
               "url":"https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxf756e2112161596a&redirect_uri=http%3a%2f%2fpet.wx.upcoder.net%2fpet%2finfo&response_type=code&scope=snsapi_base&state=123#wechat_redirect"
            }]
       }]
 }


