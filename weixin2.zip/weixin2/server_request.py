# -*- coding=utf8  -*- 


import tornado.web;
import tornado.gen as gen

import gzip,StringIO,base64
import tornado.escape
import tornado.httpclient
import logging ,md5

import weixin_conf
iwan_url = weixin_conf.server_ip

def encode_passwd(passwd):
    passwd_md5 = md5.new(passwd).hexdigest()
    passwd_encode = "";
    for i in xrange(0,len(passwd_md5), 2) :
        passwd_encode += str(int(passwd_md5[i:i+2], 16))

    return passwd_encode

def decode_data(resp):
    resp_base64 = base64.b64decode(resp)
    compressedFile = StringIO.StringIO(resp_base64)
    decompressedFile = gzip.GzipFile(fileobj=compressedFile)
    resp_original = None
    try:
        resp_original = decompressedFile.read()
        decompressedFile.close()
    finally:
        decompressedFile.close()

    jsonstr = resp_original.decode("string_escape")
    jsondata = tornado.escape.json_decode(jsonstr);
    return jsondata

def encode_data(req):
    buf = StringIO.StringIO();
    f = gzip.GzipFile(mode='wb',fileobj=buf);
    try:
        f.write(req)
        f.close()
    finally:
        f.close;

    basedata = base64.b64encode(buf.getvalue());
    return basedata

class BaseRequest(object):
    """docstring for BaseRequest"""
    def __init__(self):
        super(BaseRequest, self).__init__()
        self.req_data = None
        self.url = None
        
    @gen.coroutine
    def do_get(self,url):
        request = tornado.httpclient.HTTPRequest(url=url,method='GET')
        http = tornado.httpclient.AsyncHTTPClient()
        response = yield http.fetch(request)
        if response.error:
            logging.info(response)
            raise tornado.web.HTTPError(500)
        raise gen.Return(response)

    @gen.coroutine
    def do_post(self,url,body_text):
        request = tornado.httpclient.HTTPRequest(url=url,method='POST',body=body_text,
                            headers={'Content-Type':'multipart/form-data'})
        http = tornado.httpclient.AsyncHTTPClient()
        response = yield http.fetch(request)
        if response.error: 
            logging.info(response)
            raise tornado.web.HTTPError(500)
        raise gen.Return(response)

    def packRequest(self,req_data):
        req_encrypt = encode_data(tornado.escape.json_encode(req_data))
        proto = req_encrypt
        return tornado.escape.json_encode(proto);

    def check_response(self,body_text,response):
        if response["status_code"] != 0: 
            logging.info(body_text)


class CoorConvert(BaseRequest):
    """docstring for CoorConvert"""
    def __init__(self):
        super(CoorConvert, self).__init__()
        self.url = "http://api.map.baidu.com/geoconv/v1/?ak=8502935fbe70e9f8f1d329982e8272ab&from=1&to=5&coords="

    @gen.coroutine
    def request(self,coors):
        length = len(coors)
        newcoors = []
        geturl = self.url

        print coors

        for index,item in enumerate(coors):
            geturl = geturl + str(item['x']) + ',' + str(item['y'])
            
            if (index != 0 and index % 99 == 0) or index == length -1 :
                print geturl
                resp = yield self.do_get(geturl)
                body_json = tornado.escape.json_decode(resp.body);
                print body_json
                if body_json['status'] == 0:
                    for newcoor in body_json['result']:
                        newcoors.append(newcoor);

                geturl = self.url
            else:
                geturl = geturl + ';'

        raise gen.Return(newcoors)


class PetBindRequest(BaseRequest):
    """docstring for PetBindRequest"""
    def __init__(self):
        super(PetBindRequest, self).__init__()
        self.url = iwan_url + "/wxmsg/bind"

    @gen.coroutine
    def request(self,userid,deviceid):
        self.req_data={
            "deviceid":deviceid,
            "openid":userid}

        body_text = self.packRequest(self.req_data)
        resp = yield self.do_post(self.url,body_text)
        jsondata = decode_data(resp.body);
        self.check_response(body_text,jsondata)
        raise gen.Return(jsondata)

class GetDeviceListRequest(BaseRequest):
    """docstring for GetDeviceListRequest"""
    def __init__(self):
        super(GetDeviceListRequest, self).__init__()
        self.url = iwan_url + "/wxmsg/device_list"

    @gen.coroutine
    def request(self,userid):
        self.req_data={
            "openid":userid}

        body_text = self.packRequest(self.req_data)
        resp = yield self.do_post(self.url,body_text)
        jsondata = decode_data(resp.body);
        self.check_response(body_text,jsondata)
        raise gen.Return(jsondata)


class SetPetInfoRequest(BaseRequest):
    """docstring for SetPetInfoRequest"""
    def __init__(self):
        super(SetPetInfoRequest, self).__init__()
        self.url = iwan_url + "/wxmsg/set_petinfo"

    @gen.coroutine
    def request(self,userid,nickname,weight,height,age,sex,color,breed,pic):
        self.req_data={
            "openid" : userid,
            "nickname" : nickname,
            "weight" : weight,
            "height" : height,
            "age" : age,
            "sex" : sex,
            "color" : color,
            "breed" : breed,
            "pic" : pic}

        body_text = self.packRequest(self.req_data)
        resp = yield self.do_post(self.url,body_text)
        jsondata = decode_data(resp.body);
        self.check_response(body_text,jsondata)
        raise gen.Return(jsondata)

class GetPetInfoRequest(BaseRequest):
    """docstring for GetPetInfoRequest"""
    def __init__(self):
        super(GetPetInfoRequest, self).__init__()
        self.url = iwan_url + "/wxmsg/get_petinfo"

    @gen.coroutine
    def request(self,userid):
        self.req_data={
            "openid" : userid}

        body_text = self.packRequest(self.req_data)
        resp = yield self.do_post(self.url,body_text)
        jsondata = decode_data(resp.body);
        self.check_response(body_text,jsondata)
        raise gen.Return(jsondata)

class GetLatestPositionRequest(BaseRequest):
    """docstring for GetLatestPositionRequest"""
    def __init__(self):
        super(GetLatestPositionRequest, self).__init__()
        self.url = iwan_url + "/wxmsg/latest_position"

    @gen.coroutine
    def request(self,userid):
        self.req_data={
            "openid" : userid}

        body_text = self.packRequest(self.req_data)
        resp = yield self.do_post(self.url,body_text)
        jsondata = decode_data(resp.body);
        self.check_response(body_text,jsondata)
        raise gen.Return(jsondata)

class GetTrackByDayRequest(BaseRequest):
    """docstring for GetTrackByDayRequest"""
    def __init__(self):
        super(GetTrackByDayRequest, self).__init__()
        self.url = iwan_url + "/wxmsg/gps_track"

    @gen.coroutine
    def request(self,userid,start,end):
        self.req_data={
            "openid" : userid,
            "startdate" : start,
            "enddate" : end}

        body_text = self.packRequest(self.req_data)
        resp = yield self.do_post(self.url,body_text)
        jsondata = decode_data(resp.body);
        self.check_response(body_text,jsondata)
        raise gen.Return(jsondata)

class CreateEWallRequest(BaseRequest):
    """docstring for CreateEWallRequest"""
    def __init__(self):
        super(CreateEWallRequest, self).__init__()
        self.url = iwan_url + "/wxmsg/create_ewall"

    @gen.coroutine
    def request(self,userid,x,y,radius):
        self.req_data={
            "openid" : userid,
            "centerx" : x,
            "centery" : y,
            "radius" : radius}

        body_text = self.packRequest(self.req_data)
        resp = yield self.do_post(self.url,body_text)
        jsondata = decode_data(resp.body);
        self.check_response(body_text,jsondata)
        raise gen.Return(jsondata)


class DeleteEWallRequest(BaseRequest):
    """docstring for DeleteEWallRequest"""
    def __init__(self):
        super(DeleteEWallRequest, self).__init__()
        self.url = iwan_url + "/wxmsg/delete_ewall"

    @gen.coroutine
    def request(self,userid,ewall_id):
        self.req_data={
            "openid" : userid,
            "id" : ewall_id}

        body_text = self.packRequest(self.req_data)
        resp = yield self.do_post(self.url,body_text)
        jsondata = decode_data(resp.body);
        self.check_response(body_text,jsondata)
        raise gen.Return(jsondata)

class DownloadEWallRequest(BaseRequest):
    """docstring for DownloadEWallRequest"""
    def __init__(self):
        super(DownloadEWallRequest, self).__init__()
        self.url = iwan_url + "/wxmsg/download_ewall"

    @gen.coroutine
    def request(self,userid):
        self.req_data={
            "openid" : userid}

        body_text = self.packRequest(self.req_data)
        resp = yield self.do_post(self.url,body_text)
        jsondata = decode_data(resp.body);
        self.check_response(body_text,jsondata)
        raise gen.Return(jsondata)


class PushWeixinMessageRequest(BaseRequest):
    """docstring for PushWeixinMessageRequest"""
    def __init__(self):
        super(PushWeixinMessageRequest, self).__init__()
        self.url = iwan_url + "/wxmsg/push_msg"

    @gen.coroutine
    def request(self,userid,c_type,content):
        self.req_data={
            "openid" : userid,
            "type" : c_type,
            "content" : content
            }

        body_text = self.packRequest(self.req_data)
        resp = yield self.do_post(self.url,body_text)
        jsondata = decode_data(resp.body);
        self.check_response(body_text,jsondata)
        raise gen.Return(jsondata)


if __name__ == '__main__':
    data = encode_data("""{"dsdk":"dsdsd"}""")
    print  decode_data(data)






