# -*- coding=utf8  -*- 


from wechat_sdk.reply import WechatReply
import tornado.httpclient
import struct

import tornado.testing


class UserTextMessage(WechatReply): 
    """  
    回复设备消息
    """ 
    TEMPLATE = u""" 
     <xml>
     <ToUserName><![CDATA[{target}]]></ToUserName>
     <FromUserName><![CDATA[{source}]]></FromUserName> 
     <CreateTime>{time}</CreateTime>
     <MsgType><![CDATA[text]]></MsgType>
     <Content><![CDATA[{content}]]></Content>
     <MsgId>1234567890123456</MsgId>
    </xml>
    """
    def __init__(self,source,target,content):
        super(UserTextMessage, self).__init__(source=source,target=target,content=content)

    def render(self):
        return UserTextMessage.TEMPLATE.format(**self._args)


class DeviceTextMessage(WechatReply): 
    """  
    回复设备消息
    """ 
    TEMPLATE = u""" 
     <xml> 
     <ToUserName><![CDATA[{target}]]></ToUserName>
     <FromUserName><![CDATA[{source}]]></FromUserName> 
     <CreateTime>{time}</CreateTime>
     <MsgType><![CDATA[device_text]]></MsgType> 
     <DeviceType><![CDATA[{type}]]></DeviceType> 
     <DeviceID><![CDATA[{id}]]></DeviceID> 
     <Content><![CDATA[{content}]]></Content>
     <SessionID>1234567890</SessionID> 
     <MsgID>1234567890</MsgID> 
     <OpenID><![CDATA[{openid}]]></OpenID>
    </xml>
    """
    def __init__(self,source,target,content,type,id,openid):
        super(DeviceTextMessage, self).__init__(source=source,target=target,content=content,
            type=type,id=id,openid=openid)

    def render(self):
        return DeviceTextMessage.TEMPLATE.format(**self._args)


class DeviceEventMessage(WechatReply): 
    """  
    回复设备消息
    """ 
    TEMPLATE = u""" 
     <xml> 
     <ToUserName><![CDATA[{target}]]></ToUserName>
     <FromUserName><![CDATA[{source}]]></FromUserName> 
     <CreateTime>{time}</CreateTime>
     <MsgType><![CDATA[device_event]]></MsgType> 
     <Event><![CDATA[{event}]]></Event>
     <DeviceType><![CDATA[{devicetype}]]></DeviceType> 
     <DeviceID><![CDATA[{id}]]></DeviceID> 
     <Content><![CDATA[{content}]]></Content>
     <SessionID>1234567890</SessionID> 
     <MsgID>1234567890</MsgID> 
     <OpenID><![CDATA[{openid}]]></OpenID>
    </xml>
    """
    def __init__(self,source,target,content,type,id,openid,event):
        super(DeviceEventMessage, self).__init__(source=source,target=target,content=content,
            devicetype=type,id=id,openid=openid,event=event)

    def render(self):
        return DeviceEventMessage.TEMPLATE.format(**self._args)


def sendTextMessage(content):
    http = tornado.httpclient.HTTPClient()
    url = "http://127.0.0.1:45000/message"
    # body_text = UserTextMessage('123','123',"content").render();
    body_text = DeviceTextMessage('123','123',content,"544","454","12345678").render();
    # body_text = DeviceEventMessage('123','123',"content","544","454","12345678","subscribe").render();
    http_headers = {}
    request = tornado.httpclient.HTTPRequest(url=url,method='POST',body=body_text,headers=http_headers)
    return http.fetch(request).body

