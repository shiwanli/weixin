# -*- coding=utf8  -*- 

from tornado.testing import LogTrapTestCase,AsyncHTTPTestCase,AsyncTestCase,AsyncHTTPClient
from tornado.ioloop import IOLoop
import tornado,base64
import tornado.httpclient


from libs.weixin_msg_test import DeviceTextMessage
from libs.weixin_msg_test import UserTextMessage
from libs.weixin_msg_test import DeviceEventMessage

import sys
sys.path.append("..")
from weixin import Application
import iwan_request as iwan_req


# This test uses coroutine style.
class MyTestCase(AsyncTestCase,LogTrapTestCase):
    # @tornado.testing.gen_test
    # def test_register_fetch(self):
    #     # client = AsyncHTTPClient(self.io_loop)
    #     request = iwan_req.RegisterRequest();
    #     response = yield request.request('shiwl','123')
    #     self.assertEqual(response["stateCode"],'001');

    @tornado.testing.gen_test
    def test_getAllInfoRequest(self):
        # client = AsyncHTTPClient(self.io_loop)
        request = iwan_req.GetAllInfoRequest();
        response = yield request.request('123','123')
        # print response["stateCode"]
        self.assertNotEqual(response["stateCode"],'003');

    @tornado.testing.gen_test
    def test_loginRequest(self):
        # client = AsyncHTTPClient(self.io_loop)
        request = iwan_req.UserInfoRequest();
        response = yield request.request('123','123')
        # print response["stateCode"]
        self.assertNotEqual(response["stateCode"],'003');

    @tornado.testing.gen_test
    def test_register(self):
        request = iwan_req.RegisterRequest();
        response = yield request.request('123','123')
        # print response["stateCode"]
        self.assertNotEqual(response["stateCode"],'003');

    @tornado.testing.gen_test
    def test_weixin_server(self):
        request = iwan_req.RegisterRequest();
        response = yield request.request('123','123')
        # print response["stateCode"]
        self.assertNotEqual(response["stateCode"],'003');


class WeiXinHttpTest(AsyncHTTPTestCase,LogTrapTestCase):
    def get_app(self):
        app = Application()
        app.settings['debug'] = False

    def get_http_port(self):
        return 45000;

    def test_text_message(self):
        body_text = UserTextMessage('123','123',"12313").render();
        self.http_client.fetch(self.get_url('/message'),method='POST',body=body_text,callback=self.stop)
        response = self.wait()
        self.assertEqual(response.code,200)
        # print response.code

    def test_bind_message(self):
        body_text = DeviceEventMessage('123','123',"12313",'bind','123','123','bind').render();
        self.http_client.fetch(self.get_url('/message'),method='POST',body=body_text,callback=self.stop)
        response = self.wait()
        self.assertEqual(response.code,200)
        # print response.code

    def test_device_message(self):
        content = base64.standard_b64encode("AT+CONN:")
        body_text = DeviceTextMessage('123','123',content,"544","454","12345678").render();
        self.http_client.fetch(self.get_url('/message'),method='POST',body=body_text,callback=self.stop)
        response = self.wait()
        self.assertEqual(response.code,200)
        # print response.code

        content = base64.standard_b64encode("AT+CONN:")
        body_text = DeviceTextMessage('123','123',content,"544","454","12345678").render();
        self.http_client.fetch(self.get_url('/message'),method='POST',body=body_text,callback=self.stop)
        response = self.wait()
        self.assertEqual(response.code,200)
        # print response.code



class MyHTTPTest(AsyncHTTPTestCase,LogTrapTestCase):
    def get_app(self):
        app = Application()
        app.settings['debug'] = False

    def get_http_port(self):
        return 45000

    def test_home(self):
        self.http_client.fetch(self.get_url('/'),self.stop)
        response = self.wait()
        # print response.code
        self.assertEqual(response.code , 200)
        # test contents of response

    def test_sport(self):
        self.http_client.fetch(self.get_url('/detail/sport'),self.stop)
        response = self.wait()
        # print response.code
        self.assertEqual(response.code , 200)

    def test_sleep(self):
        self.http_client.fetch(self.get_url('/detail/sleep'),self.stop)
        response = self.wait()
        # print response.code
        self.assertEqual(response.code , 200)

    def test_money(self):
        self.http_client.fetch(self.get_url('/detail/money'),self.stop)
        response = self.wait()
        # print response.code
        self.assertEqual(response.code , 200)

    def test_info(self):
        self.http_client.fetch(self.get_url('/setting/info'),self.stop)
        response = self.wait()
        # print response.code
        self.assertEqual(response.code , 200)

    def test_alarm(self):
        self.http_client.fetch(self.get_url('/setting/alarm'),self.stop)
        response = self.wait()
        # print response.code
        self.assertEqual(response.code , 200)

    def test_aim(self):
        self.http_client.fetch(self.get_url('/setting/aim'),self.stop)
        response = self.wait()
        # print response.code
        self.assertEqual(response.code , 200)


if __name__ == '__main__':
    tornado.testing.main(verbosity=2)





