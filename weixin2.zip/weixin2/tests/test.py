# -*- coding=utf8  -*- 


import base64



# data = "AAAB4AABgAACHAABgAACdQACgAAC6QAEgAADdgAHgAAEGgALgAAE0wAQgAAFnwAWgAAGfAAdgAAHaAAlgAAIYQAugAAJZQA4gAAKcgBDgAALhgBPgAAMnwBcgAANuwBqgAAO2AB5gAAP9ACJgAARDQCagAASIQCsgAATLgC/gAATagDTgAATwwDogAAUNwD+"
# newdata = base64.standard_b64decode(data)
# print len(newdata)

# a = '? (08@'
# print a.encode('hex')


# print ["AT+DATA=%d\r\n" %(x) for x in xrange(10,0,-1)]

# import datetime
# today = datetime.date.today()
# print today

# import weixin_platform_tools as weixin_tools
# weixin_tools.sendTextMessage('oBC2gji84Ky30dDPp60MmDIsd4Os',"正在更新数据,请不要离开公众号")


import time

print time.time()