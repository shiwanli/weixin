# -*- coding=utf8  -*- 

from wechat_sdk.messages import handle_for_type
from wechat_sdk.messages import WechatMessage
from wechat_sdk.messages import MESSAGE_TYPES
from wechat_sdk.messages import UnknownMessage
from wechat_sdk.exceptions import ParseError


@handle_for_type("device_text") 
class DeviceTextMessage(WechatMessage):
    def __init__(self, message): 
        try:                  
            self.deviceType = message.pop('DeviceType') 
            self.deviceID = message.pop('DeviceID') 
            
            self.content = None
            if message.has_key('Content'):
                self.content = message.pop('Content')

            self.sessionID = message.pop('SessionID') 
            self.openID = message.pop('OpenID') 

        except KeyError: 
            raise ParseError()
        super(DeviceTextMessage, self).__init__(message)

@handle_for_type("device_event") 
class DeviceEventMessage(WechatMessage):
    def __init__(self, message): 
        try:                  
            self.deviceType = message.pop('DeviceType') 
            self.deviceID = message.pop('DeviceID')
            self.sessionID = message.pop('SessionID') 
            self.event = message.pop('Event')

            self.content = None
            if message.has_key('Content'):
                self.content = message.pop('Content')

            if(self.event=='subscribe_status' or self.event=='unsubscribe_status'):
                self.opType = message.pop('OpType')

            self.openID = message.pop('OpenID')

        except KeyError: 
            raise ParseError()
        super(DeviceEventMessage, self).__init__(message) 


def get_message(message):
    print MESSAGE_TYPES
    message_type = MESSAGE_TYPES.get(message['type'], UnknownMessage)
    return message_type(message)





