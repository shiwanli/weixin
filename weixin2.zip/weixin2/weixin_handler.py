# -*- coding=utf8  -*- 

import tornado.gen as gen


import random

import tornado.httpserver
import tornado.web
import tornado.httpclient

import weixin_platform_tools

import logging


# 处理微信消息
class WeixinHandler(tornado.web.RequestHandler):
    # 服务器配置测试接口
    def get(self):
        wechat = weixin_platform_tools.GetToken()

        print self.request.body
        print self.request.headers

        signature = self.get_argument('signature')
        timestamp = self.get_argument('timestamp')
        nonce = self.get_argument('nonce')
        echostr = self.get_argument('echostr')

        if wechat.check_signature(signature=signature, timestamp=timestamp, nonce=nonce):
            self.write(echostr)

    # 微信消息提交
    @tornado.web.asynchronous
    def post(self):
        # 对签名进行校验
        wechat = weixin_platform_tools.GetToken()

        signature = self.get_argument('signature',123)
        timestamp = self.get_argument('timestamp',123)
        nonce = self.get_argument('nonce',123)

        if 123 == signature or wechat.check_signature(signature=signature, timestamp=timestamp, nonce=nonce):
            # 对 XML 数据进行解析 (必要, 否则不可执行 response_text, response_image 等操作)
            body_text = self.request.body
            wechat.parse_data(body_text)
            # 获得解析结果, message 为 WechatMessage 对象 (wechat_sdk.messages中定义)
            message = wechat.get_message()
            
            # logging.info(message.type)
            print message.type, message.source
            if( message.type == 'click'):
                self.OnEventMessage(wechat,message)
            elif( message.type == 'text'):
                self.OnTextMessage(wechat,message)
            elif( message.type == 'device_text'):
                self.OnDeviceText(wechat,message)
            elif( message.type == 'device_event'):
                self.OnDeviceEvent(wechat,message)
            else:
                self.write('')
                self.finish();
        else :
            self.write('error message')
            self.finish();
            

    def getOpenID(self,message):
        openID = message.source;
        return openID;


    # 文本消息
    def OnTextMessage(self,wechat,message):
        reply_string = ['hello,who are you', 
        'i am a robot, don\'t trust me',
        'i love you',
        'you are a good boy',
        'haha , what are you talking about',
        'say some fresh']
        text = wechat.response_text(reply_string[int(random.random()*len(reply_string))])
        self.write(text)
        self.finish()

    # 设备主动发的消息
    @gen.coroutine
    def OnDeviceText(self,wechat,message):
        # 给服务器的返回
        openid = message.source;
        device_type = message.deviceType
        device_id = message.deviceID
        datactrl = iwan_device_ctrl.getControl(openid,device_type,device_id);
        return_text = yield datactrl.handleData(wechat,message);
        reply = weixin_msgRepExt.DeviceTextMessage(message=message,deviceType=message.deviceType,
            deviceID=message.deviceID,sessionID=message.sessionID,content=return_text)
        self.write(reply.render())
        self.finish()

    # 微信设备事件
    @gen.coroutine
    def OnDeviceEvent(self,wechat,message):
        logging.info("%s %s" %(message.source ,message.event))
        if message.event == 'bind':
            self.write('')
            self.finish()
        elif message.event == 'unbind':
            self.write('')
            self.finish()
        elif message.event == 'subscribe':
            self.write('')
            self.finish()
        elif message.event == 'unsubscribe':
            self.write('')
            self.finish()
        else:
            self.write('unimplement')
            self.finish()

    # 微信菜单事件
    def OnEventMessage(self,wechat,message):
        if(message.key == 'V1001_TODAY_RANK'):
            self.OnRank(wechat,message)
        elif(message.key == 'V1001_TODAY_SPORT'):
            self.OnSport(wechat,message)
        elif(message.key == 'V1001_TODAY_SLEEP'):
            self.OnSleep(wechat,message)
        elif(message.key == 'V1001_TODAY_MONEY'):
            self.OnCoins(wechat,message)

    def OnRank(self,wechat,message): # 睡眠排名
        # openID = self.getOpenID(message);
        return_text = weixin_msgRepExt.DeviceRankMessage(message).render()
        self.write(return_text)
        self.finish()

    @gen.coroutine
    def OnSport(self,wechat,message): # 今日运动
        pass;

    @gen.coroutine
    def OnSleep(self,wechat,message): # 今日睡眠
        pass;

    @gen.coroutine
    def OnCoins(self,wechat,message): # 今日金币
        pass;


if __name__ == '__main__':
    pass












