# -*- coding=utf8  -*- 

import tornado.httpserver
import tornado.ioloop
import tornado.options
import tornado.web
import tornado.gen as gen
import tornado.httpclient
import tornado.escape
import logging  
import datetime,calendar
import base64


from tornado.options import define, options
define("port", default=23655, help="run on the given port", type=int)

from weixin_handler import WeixinHandler

import server_request as server
import weixin_platform_tools as wx_tools
import os



class BaseHandler(tornado.web.RequestHandler):

    @gen.coroutine
    def getOpenID(self):
        userid = self.get_secure_cookie("openid",None)
        if(userid != None):
            raise gen.Return(userid)

        print 'openid is ', userid
        code = self.get_argument("code",[""])
        url = """https://api.weixin.qq.com/sns/oauth2/access_token?appid=wxf756e2112161596a&secret=2be39d0a0388e49fc7db4dcfd746f359&code=%s&grant_type=authorization_code""" %(code)
        request = tornado.httpclient.HTTPRequest(url=url,method='GET')
        http = tornado.httpclient.AsyncHTTPClient()
        resp = yield http.fetch(request)

        body_data =  tornado.escape.json_decode(resp.body)
        if body_data.has_key('openid'):
            cookie = body_data['openid']
            print 'set cookit = ',cookie
            self.set_secure_cookie("openid",cookie)
            raise gen.Return(cookie)
        else:
            raise gen.Return("");

    @gen.coroutine  
    def getAvaidOpenID(self):
        openid = self.get_argument('openid',None);
        if openid == None:
             openid = yield self.getOpenID()

        raise gen.Return(openid)

    def getDatetime(self):
        date_time = datetime.date.today();
        date_arg = self.get_argument('date',None);
        if date_arg != None:    
            date_time = datetime.datetime.strptime(date_arg,'%Y%m%d').date()

        return date_time

    def getDeviceID(self):
        device_id = self.get_argument('deviceid',None);
        if device_id != None:    
            return device_id

        return "123456789"

    def log_exception(self, typ, value, tb):
        print value,typ,tb



class ServerTest(BaseHandler):
    @gen.coroutine
    def get(self):

        # userid = yield self.getAvaidOpenID()
        # deviceid = self.getDeviceID()

        # request = server.PetBindRequest()
        # response = yield request.request(userid,deviceid)
        # print response;

        # request = server.GetDeviceListRequest()
        # response = yield request.request(userid)
        # print response;

        # request = server.SetPetInfoRequest()
        # response = yield request.request(userid,'a','1','1','1','1','1','1','1')
        # print response;

        # request = server.GetPetInfoRequest()
        # response = yield request.request(userid)
        # print response;

        # request = server.GetLatestPositionRequest()
        # response = yield request.request(userid)
        # print response;

        # start = datetime.datetime.utcnow()
        # start = start.replace(hour=0,minute=0,second=0,microsecond=0);
        # end = start + datetime.timedelta(days=1);

        # ts = calendar.timegm(start.utctimetuple())
        # te = calendar.timegm(end.utctimetuple())

        # print ts,te;
        # request = server.GetTrackByDayRequest()
        # response = yield request.request(userid,ts,te)
        # print response

        # request = server.CreateEWallRequest()
        # response = yield request.request(userid,113.2,22.3,1000)
        # print response;

        # request = server.DeleteEWallRequest()
        # response = yield request.request(userid,0)
        # print response;

        # request = server.DownloadEWallRequest()
        # response = yield request.request(userid)
        # print response;

        # request = server.PushWeixinMessageRequest()
        # response = yield request.request(userid,'text',base64.b64encode('kdkksdjlfsjflsjdfklsdfs'))
        # print response;

        # self.write("we got it!")
        self.render("test.html")


class TrackLatestPositionHandler(BaseHandler):
    """docstring for TrackLatestPositionHandler"""
    @gen.coroutine
    def get(self):
        userid = yield self.getAvaidOpenID();
        request = server.GetLatestPositionRequest()
        response = yield request.request(userid)
        print response;
        if response['status_code'] == 0:
            response['postion']['x'] = int(response['postion']['x']) / 100000000.0;
            response['postion']['y'] = int(response['postion']['y']) / 100000000.0;
            request = server.CoorConvert()
            newCoors = yield request.request([response['postion']])
            response['postion'] = newCoors[0]

            self.render("lastpoint.html",point=response['postion'])


        
class TrackPageHandler(BaseHandler):
    """docstring for getTrackHandler"""
    @gen.coroutine
    def get(self):
        self.render("track.html")

class TrackAjaxHandler(BaseHandler):
    """docstring for TrackAjaxHandler"""
    @gen.coroutine
    def get(self):
        userid = yield self.getAvaidOpenID();
        userid = 'oBC2gji84Ky30dDPp60MmDIsd4Os'
        sdate = self.get_argument("date");
        start = datetime.datetime.strptime(sdate,"%Y-%m-%d");
        start = start.replace(hour=0,minute=0,second=0,microsecond=0);
        end = start + datetime.timedelta(days=1);

        import calendar
        ts = calendar.timegm(start.utctimetuple())
        te = calendar.timegm(end.utctimetuple())

        request = server.GetTrackByDayRequest()
        response = yield request.request(userid,ts,te)

        if response['status_code'] == 0:
            for item in response['locs']:
                item['x'] = int(item['x']) / 100000000.0
                item['y'] = int(item['y']) / 100000000.0

            request = server.CoorConvert()
            newCoors = yield request.request(response['locs'])
            response['locs'] = newCoors
            self.write(response)

class EWallNewPageHandler(BaseHandler):
    """docstring for EWallListPageHandler"""
    @gen.coroutine
    def get(self):
        self.render("ewall_new.html")


class EWallListPageHandler(BaseHandler):
    """docstring for EWallListPageHandler"""
    @gen.coroutine
    def get(self):
        userid = yield self.getAvaidOpenID();
        request = server.DownloadEWallRequest()
        response = yield request.request(userid)
        print response;
        if response['status_code'] == 0:
            self.render("ewall_list.html",ewalls=response['fencings'])


class EWallViewPageHandler(BaseHandler):
    """docstring for EWallViewPageHandler"""
    @gen.coroutine
    def get(self):
        id = self.get_argument('id')
        x = self.get_argument('x')
        y = self.get_argument('y')
        radius = self.get_argument('radius')
        self.render("ewall_delete.html",id=id,x=x,y=y,radius=radius)

    @gen.coroutine
    def post(self):
        userid = yield self.getAvaidOpenID();
        userid = "123456"

        id = self.get_body_argument('id')
        request = server.DeleteEWallRequest()
        response = yield request.request(userid,id)
        print response;

        self.write(response['status_msg'])

class PetInfoHandler(BaseHandler):
    """docstring for getEWall"""
    @gen.coroutine
    def get(self):
        userid = yield self.getAvaidOpenID();
        request = server.GetPetInfoRequest()
        response = yield request.request(userid)
        print response;
        if not response.has_key('pet_info'):
            response['pet_info'] = {
                'nickname':'honey',
                'age':"1/1/2010",
                'weight':10,
                'height':10,
                'sex':1,
                'breed':1,
                'color':'red',
            }

        self.render("petinfo.html",petinfo=response['pet_info'])
        

    @gen.coroutine
    def post(self):
        userid = yield self.getAvaidOpenID();
        nickname = self.get_body_argument('nickname');
        weight = self.get_body_argument('weight');
        height = self.get_body_argument('height');
        sex = self.get_body_argument('sex');
        age = self.get_body_argument('age');
        color = self.get_body_argument('color');
        breed = self.get_body_argument('breed');

        userid = "123456"
        print userid,nickname,weight,height,sex,age,color,breed

        request = server.SetPetInfoRequest()
        response = yield request.request(userid,nickname,weight,height,sex,age,color,breed,"")
        print response;

        self.write(response['status_msg'])


class PetBindHandler(BaseHandler):
    @gen.coroutine
    def get(self):
        userid = yield self.getAvaidOpenID();
        self.render('band.html',id=userid);

    @gen.coroutine
    def post(self):
        userid = yield self.getAvaidOpenID();
        deviceid = self.get_body_argument('id');

        request = server.PetBindRequest()
        response = yield request.request(userid,deviceid)
        self.write(response['status_msg'])

class deviceNotifyHandler(BaseHandler):
    @gen.coroutine
    def post(self):
        pass

class AboutHandler(object):
    """docstring for AboutHandler"""
    def get(self):
        pass
        
class Application(tornado.web.Application):
    def __init__(self):
        handlers = [
            (r"/", ServerTest),
            (r"/message", WeixinHandler),
            (r"/pet/info", PetInfoHandler),
            (r"/pet/bind", PetBindHandler),
            (r"/ewall/new", EWallNewPageHandler),
            (r"/ewall/view", EWallViewPageHandler),
            (r"/ewall/list", EWallListPageHandler),
            (r"/track/latest", TrackLatestPositionHandler),
            (r"/track/ajax", TrackAjaxHandler),
            (r"/track/history", TrackPageHandler),
            (r"/device/notify",deviceNotifyHandler),
        ]
        settings = dict(
            template_path=os.path.join(os.path.dirname(__file__), "templates"),
            static_path=os.path.join(os.path.dirname(__file__), "static"),
            debug=True,
            cookie_secret="61oETzKXQAGaYdkL5gEmGeJJFuYh7EQnp2XdTP1o/Vo="
        )
        tornado.web.Application.__init__(self, handlers, **settings)


if __name__ == "__main__":
    import sys
    reload(sys)
    sys.setdefaultencoding("utf-8")

    print wx_tools.InitPlatform()
    print wx_tools.GetToken()
    # print wx_tools.DeleteMenus()
    # print wx_tools.CreateMenus()
    tornado.options.parse_command_line()
    tornado.options.options.logging=None

    http_server = tornado.httpserver.HTTPServer(Application(),xheaders=True)
    http_server.listen(options.port)
    logging.info('running ... on ' + str(options.port)) 

    # iwan_device_ctrl.addYankControl()
    tornado.ioloop.IOLoop.instance().start()
    

    



